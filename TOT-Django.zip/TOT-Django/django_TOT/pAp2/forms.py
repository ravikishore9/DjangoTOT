from django.forms import ModelForm
from pAp2.models import Student

class StudentForm(ModelForm):
	class Meta:
		model=Student
		fields='__all__'