from django.shortcuts import render
from pAp2.models import Student
from pAp2.forms import StudentForm


# Create your views here.
def register(request):
	if request.method=="POST":
		form=StudentForm(request.POST)
		if form.is_valid():
			form.save()
			messages.success(request,request.POST['studentname']+' record saved Successfully')
			messages.info(request,'now you can add new record')
			return redirect('/myapp2/register')
		#return HttpResponse("saved Successfully")
	form=StudentForm()
	return render(request,'myApp2/register.html',{'form':form})