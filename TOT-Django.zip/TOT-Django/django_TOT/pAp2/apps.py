from django.apps import AppConfig


class Pap2Config(AppConfig):
    name = 'pAp2'
