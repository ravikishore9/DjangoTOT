from django.db import models

# Create your models here.
class Student(models.Model):
	branchs=[('C,S,E','c,s,e'),
			 ('E,E,E','e,e,e'),
			 ('E,C,E','e,c,e'),
			 ('E,E,E','e,e,e'),
			 ('I.T','i.t')
			 ]
	studentid=models.CharField(max_length=30)
	studentname=models.CharField(max_length=50)
	branch=models.CharField(max_length=50,choices=branchs)
	age=models.IntegerField()


