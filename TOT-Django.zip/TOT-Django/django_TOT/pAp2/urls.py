from django.urls import path
from pAp2 import views

urlpatterns=[
	path('register',views.register,name='register')
]