function sam(){
    var a = document.getElementById('na').value
    var b = document.getElementById('nu').value
    alert(a+'\n'+b)
}