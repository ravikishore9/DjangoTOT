from django.apps import AppConfig


class PapConfig(AppConfig):
    name = 'pAp'
